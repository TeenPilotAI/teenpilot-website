# Fonts

| File | Family | Weight | Role |
|---|---|---|---|
| `Syne-ExtraBold.ttf` | Syne | 800 | Wordmark & headings |
| `DMSans-Regular.ttf` | DM Sans | 400 | Body & UI |

Both families are licensed under the **SIL Open Font License, Version 1.1** —
free for commercial use, modification, and **embedding**. Full licence:
<https://openfontlicense.org>.

- **Syne** — © The Syne Project Authors. <https://fonts.google.com/specimen/Syne>
- **DM Sans** — © The DM Sans Project Authors. <https://fonts.google.com/specimen/DM+Sans>

Shipped here: Syne 800 (the wordmark weight) and DM Sans Regular. The **full
weight ranges** (DM Sans 100–1000, Syne 400–800) are on Google Fonts at the
links above. The lockup artwork needs **no** font — the wordmark is outlined.
