# TeenPilot — Brand Pack

Human-usable marketing assets (Canva, social, print, hand-off to a designer),
**rendered from the kit's exact vectors**. The kit — `/brand/mark.svg`,
`mark-glyph.svg`, `lockup-horizontal.svg`, `lockup-stacked.svg`, `BRAND.md` —
stays the single source of truth; this folder is the export layer. Nothing here
redraws the geometry.

**Download the whole pack:** [`teenpilot-brand-pack.zip`](../teenpilot-brand-pack.zip) ·
**Browse online:** [`/brand/pack.html`](../pack.html)

---

## What's inside

```
pack/
├─ mark/        the full Constellation Plane — 6 sizes × 5 treatments + SVG master
├─ glyph/       the solid small-size dart — 6 sizes × 5 treatments + SVG master
├─ lockups/     horizontal + stacked, 3 widths × 6 treatments + SVG masters
├─ avatars/     the mark in all 8 accents (mark-*) + each avatar's own icon (icon-*)
├─ social/      og 1200×630 · square 1080 · story 1080×1920 · profile 512 (sky)
├─ reference/   swatches.png — the colour + type sheet
├─ fonts/       Syne 800 + DM Sans (OFL) + note
└─ BRAND-PACK.md (this file)
```

PNGs are transparent unless the name says otherwise. Every asset is 1:1 (no
retina doubling) — the number in the filename **is** the pixel size.

---

## The mark & the glyph

- **Mark** (`mark/`) — the six-star constellation dart. Use at **≥56 px**.
- **Glyph** (`glyph/`) — the solid dart with the nose star, the designed
  collapse for **<56 px** (favicons, tiny chrome). The constellation's hairlines
  don't survive small rasters; the swap is part of the design.

### Treatments (both mark & glyph, all 6 sizes 2048→64)

| Suffix | Meaning |
|---|---|
| `-green-` | brand green `#4ade80` on transparent |
| `-white-` | white on transparent (for photos / dark) |
| `-ink-` | dark ink `#0a0f1a` on transparent (for light / print) |
| `-green-on-dark-square-` | green on a solid brand-dark square (opaque) |
| `-green-on-dark-rounded-` | green on a brand-dark **rounded** square (transparent corners) |

e.g. `mark/mark-green-1024.png`, `glyph/glyph-ink-256.png`.

---

## Lockups

Two-channel by design (`BRAND.md` "tint law"): **"Teen" = ink**, **the mark +
"Pilot" = accent** (brand green). Wordmarks are **outlined Syne 800** — no font
dependency. Horizontal + stacked, at 2048 / 1024 / 512 wide.

| Suffix | Use |
|---|---|
| `-brand-` | full-colour, **dark ink** "Teen" + green — for **light** backgrounds |
| `-brandwhite-` | full-colour, **white** "Teen" + green — for **dark** backgrounds |
| `-green-` / `-white-` / `-ink-` | one-colour (mono) versions on transparent |
| `-on-dark-` | full-colour lockup on a brand-dark rounded panel |

e.g. `lockups/lockup-horizontal-brandwhite-2048.png`.

---

## Avatars

The app's assistant IS the chosen avatar, and its accent tints the logo.

- **`mark-<avatar>-{1024,256}.png`** — the constellation mark in each of the 8
  live avatar accents (transparent).
- **`icon-<avatar>-{1024,256}.png`** and **`…-dark.png`** — each avatar's **own**
  glyph in its accent: Co-Pilot wears the brand mark; the others wear their own
  Tabler glyph (Luna ♪, BlockBrain ⬛, ARIA ⚛, Hoshi ⛩, Rex 🦴, Coach 🏆, Neo 🎮).
  `-dark` = on a brand-dark rounded square (app-icon style).

---

## Colour reference

Verified against the live app avatar map (`src/App.jsx`).

### Core
| Name | Dark | Light |
|---|---|---|
| Brand green | `#4ade80` | `#16a34a` |
| Brand dark | `#0a0f1a` | — |
| TeamPilot teal (coach lane) | `#2dd4bf` | `#0d9488` |
| Text / ink | `#f0f4ff` (on dark) | `#0a0f1a` (on light) |

### Avatar accents
| Avatar | Dark | Light |
|---|---|---|
| Co-Pilot | `#4ade80` | `#16a34a` |
| Luna | `#f472b6` | `#db2777` |
| BlockBrain | `#fbbf24` | `#d97706` |
| ARIA | `#ef4444` | `#dc2626` |
| Hoshi-sensei | `#a78bfa` | `#7c3aed` |
| Rex | `#22d3ee` | `#0891b2` |
| Coach | `#f87171` | `#e11d48` |
| Neo | `#fbbf24` | `#d97706` |

The **light** column is the app's `ACCENT_LIGHT` counterpart (used in light mode
so accents stay readable on white).

---

## Type

| Role | Family | Weight | Licence |
|---|---|---|---|
| Wordmark & headings | **Syne** | 800 (ExtraBold) | SIL Open Font License 1.1 |
| Body & UI | **DM Sans** | 400 / 500 / 600 | SIL Open Font License 1.1 |

Both are free for commercial use **and embedding** (OFL 1.1). Source: Google
Fonts — <https://fonts.google.com/specimen/Syne> ·
<https://fonts.google.com/specimen/DM+Sans>. `fonts/` ships Syne 800 and DM Sans
Regular for convenience; the full weight ranges are on Google Fonts. The lockup
files need **no** font (the wordmark is outlined).

---

## Clear-space & don'ts (from `/brand/BRAND.md`)

- **Clear-space:** keep the nose star's diameter (~11 % of mark height) free on
  every side of the mark or lockup.
- Don't stretch, skew, rotate, or re-proportion the geometry; don't move or add
  stars.
- One tint at a time — ink, white, brand green, or a real avatar accent only.
  Never two colours inside the mark.
- No drop shadows, glows, gradients, or outlines on the mark itself. The night
  sky in the icon compositions is the only sanctioned backdrop.

---

## Regeneration

Every raster here is rendered headless from the kit SVGs (`/brand/*.svg`) + the
Tabler outline glyphs + the two OFL fonts, tinted from the live avatar map — so
when the mark or an accent changes, the pack is re-rendered from the same
vectors. It is an **export** of the kit, never a second source.
